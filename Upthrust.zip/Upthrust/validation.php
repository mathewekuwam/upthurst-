  <?php
  session_start();

  include("connection.php");
  include("function.php");


  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
    //something was posted
    $email = $_POST['email'];
    $password = $_POST['password'];


    if(!empty($email) && !empty($password) )
    {

      //read from database
      $query = "select * from login where email = '$email' limit 1";
      $result = mysqli_query($con, $query);

      if($result)
      {
        if($result && mysqli_num_rows($result) > 0)
        {

          $user_data = mysqli_fetch_assoc($result);
          
          if($user_data['password'] === $password)
          {

            $_SESSION['userid'] = $user_data['userid'];
            header("Location: index.php");
            die;
          }
        }
      }
      // window.alert()
      echo "<script type='text/javascript' > alert('wrong username or password!');window.location='index.php'</script>";
      
          // echo "wrong username or password!";
    }

    else
    {
      echo "wrong username or password!";
    }

    
  }
?>
