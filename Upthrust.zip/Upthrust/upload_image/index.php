<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "image_upload");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
  	$image_text = mysqli_real_escape_string($db, $_POST['image_text']);
    // Get price
    $price =mysqli_real_escape_string($db, $_POST['price']);


  	// image file directory
  	$target = "images/".basename($image);

  	$sql = "INSERT INTO images (image, image_text,price) VALUES ('$image', '$image_text','$price')";
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM images");
?>
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <style>
      html, body {
      display: flex;
      justify-content: center;
      font-family: Roboto, Arial, sans-serif;
      font-size: 15px;
      }
      form {
      border: 5px solid #f1f1f1;
      }
      input[type=text], input[type=password] {
      width: 100%;
      padding: 16px 8px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
      }
      button {
      background-color: #8ebf42;
      color: white;
      padding: 14px 0;
      margin: 10px 0;
      border: none;
      cursor: grabbing;
      width: 100%;
      }
      h1 {
      text-align:center;
      fone-size:18;
      }
      button:hover {
      opacity: 0.8;
      }
      .formcontainer {
      text-align: left;
      margin: 24px 50px 12px;
      }
      .container {
      padding: 16px 0;
      text-align:left;
      }
      span.psw {
      float: right;
      padding-top: 0;
      padding-right: 15px;
      }
      /* Change styles for span on extra small screens */
      @media screen and (max-width: 300px) {
      span.psw {
      display: block;
      float: none;
      }
    </style>
</head>
<body>
<div id="content">
  <?php
    while ($row = mysqli_fetch_array($result)) {
      echo "<div id='img_div'>";
      	echo "<img src='images/".$row['image']."' >";
          echo "<p>".$row['price']."</p>";
      	echo "<p>".$row['image_text']."</p>";
      echo "</div>";
    }
  ?>
<!--   <form method="POST" action="index.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div>
  	  <input type="file" name="image">
  	</div>
  	<div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="image_text" 
      	placeholder="Say something about this image..."></textarea>
  	</div>
  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
  </form> -->


    <form method="POST" action="admin.php" enctype="multipart/form-data">
      <h1>Upload files</h1>
      <div class="formcontainer">
      <hr/>
      <div class="container">
        <label for="uname"><strong>image</strong></label>
          <input type="hidden" name="size" value="1000000">
          <div>
            <input type="file" name="image" required>
          </div>
        <!-- <input type="text" placeholder="Enter Username" name="uname" required> -->
        <label for="price"><strong>price</strong></label>
      <!--    <input type="text" placeholder="Enter price" name="price" required> -->
          <div>
            <input type="number" placeholder="Enter price" name="price" required>
          </div>

        <label for="psw"><strong>image-text</strong></label>
          <div>
            <textarea 
              id="text" 
              cols="40" 
              rows="4" 
              name="image_text" 
              placeholder="Say something about this image..."></textarea>
          </div>
       <!--  <input type="password" placeholder="Enter Password" name="psw" required> -->
      </div>

      <button type="submit" name="upload">submit</button>
  
    </form>




</div>
</body>
</html>