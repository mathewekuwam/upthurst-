                        <?php 
session_start();

	include("connection.php");
	include("function.php");
	// header('Location')


	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$email = $_POST['email'];
		$password = $_POST['password'];

		if(!empty($email) && !empty($password)  )
		{

		
			//save to database
			$userid = random_num(20);
			$query = "insert into login (userid,email, password) values ('$userid','$email','$password')";

			mysqli_query($con, $query);

			header("Location: index.php");
			die;
		}else
		{
			echo "Please enter some valid information!";
		}
	}
?>





